AXI ACADEMY — LOGO KIT  v1.0 (2026)
===================================

START HERE: open 00_Axi-Academy-Logo-Guidelines.pdf (9 pages: versions, colours,
clear space, minimum sizes, typography, do's and don'ts, which file to use).

FOLDERS
  01_Logo/SVG                 Vector. Website, apps, Figma, Illustrator. First choice for digital.
  01_Logo/PDF-print           Vector PDF for printers, InDesign, signage.
  01_Logo/EPS-print           Vector EPS for older print workflows.
  01_Logo/PNG-transparent     Transparent PNGs in 4 sizes (PowerPoint, Word, Canva).
  02_Logo-on-background       Ready previews on gradient / white / black / red.
  03_Favicon-and-App-icon     favicon.ico, favicon.svg, apple-touch-icon, Android icons,
                              app-store icon 1024, site.webmanifest.
  04_Social-media             Profile pictures, Instagram, Story, X, LinkedIn, Facebook,
                              YouTube, website share (OG) image — exact platform sizes.
  05_Brand-backgrounds        The Axi gradient as PNG and SVG.
  06_Web-developer            brand-tokens.css / .json, head-snippet.html, og-image.
  07_Source                   Master artboard (all versions) + the approved reference images.

VERSIONS
  Lockups : horizontal (website header) · vertical (posters, social) · symbol (icons)
  Colours : white (primary, on gradient/dark) · dark (on white/light)
            mono-white · mono-black (single colour)
  Names   : axi-academy-[lockup]-[colour]-[size].ext

COLOURS
  Axi Red        #E4002E  RGB 228 0 46    CMYK 0 100 80 0   (nearest Pantone 185 C)
  Eclipse Black  #090A0D  RGB 9 10 13     CMYK 60 40 40 100
  White          #FFFFFF
  Gradient       180deg  #607880 -> #94A4AA 50% -> #D4DADD 85% -> #EEF0F1

FONTS
  ACADEMY in the logo is Inter Bold, already converted to outlines (no font needed).
  Brand text: Inter (Latin) + Noto Sans Arabic (Arabic) — free on Google Fonts.

WEBSITE QUICK START
  1. Copy everything in 03_Favicon-and-App-icon to the site root.
  2. Paste 06_Web-developer/head-snippet.html into <head>.
  3. Header logo: 01_Logo/SVG/horizontal/axi-academy-horizontal-white.svg
     (use the -dark version if the header is white).

IMPORTANT
  The "axi" letters in these files were redrawn as clean vectors from the approved
  design. Before final printing, swap in the official axi master artwork from Axi HQ
  (same position and size) so the master brand is pixel-identical.
