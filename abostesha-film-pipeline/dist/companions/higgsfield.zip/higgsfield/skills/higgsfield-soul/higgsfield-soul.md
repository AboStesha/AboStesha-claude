---
name: higgsfield-soul
description: "Creates and manages reusable character profiles (Soul IDs) for consistent facial and stylistic identity across multiple image and video generations. Provides identity-vs-motion prompt separation, character sheet creation workflows, micro-expression direction, and Soul Cast AI actor configuration. Use when the user wants to maintain character consistency across multiple generations, asks about Soul ID, creating reusable characters, or generating consistent people across different scenes and shots."
user-invocable: true
metadata:
  tags: [higgsfield, soul, character, consistency, Soul ID, identity]
  version: 3.11.0
  updated: 2026-09-26
  parent: higgsfield
---

# Higgsfield Soul ID — Character Consistency

## QUICK FACTS
*Generated-checked block (scripts/build_index.py verifies anchors). Read the linked sections for full context — these lines are routing aids, not the rules themselves.*
- Hard rule: every Soul ID prompt splits into Identity Block (static descriptors only) + Motion Block (temporal/camera only) [→](#identity-vs-motion-separation--hard-rule)
- Don't re-describe the face or core features — only describe what differs from the base character [→](#prompting-with-soul-id)
- Reference image rules: front or 3/4 angle, even lighting, neutral-to-slight expression, no blur, solo subject [→](#creating-a-strong-soul-id-reference)
- Reference generators: Soul 2.0 (fashion-forward), Nano Banana Pro (max sharpness), Seedream 4.5 (style range) [→](#creating-a-strong-soul-id-reference)
- Character sheet angles: front face, 3/4, side profile, optional full body + optional embedded prop sheets [→](#character-sheet-creation)
- Two-image floor per character: one clear face + one full body, on neutral grey — never a single image; the grey law's shade and mechanism live once in `../../templates/ad-asset-prep.md` [→](#character-sheet-creation)
- **The Untouched Base**: face pass in close-up, then a looks pass; the base close-up is never run through a model again — changes go on with masks, and a new state is a new named asset [→](#the-untouched-base--build-a-character-in-two-passes)
- **Reference plates**: biological realism ON, photographic capture behaviour OFF (no key direction, cast shadow, bokeh, flare); the background is a field, not a room; lean prompts once a reference carries identity [→](#the-reference-plate--the-two-axes)
- Prefer the single-prompt 3×2 six-panel sheet (one 16:9 generation) — identity locks better than multi-step assembly [→](#single-prompt-6-panel-character-sheet-32-grid)
- Outfit change without identity drift: split-panel sheet — ghost-mannequin outfit LEFT + "face matches input 100%" close-up RIGHT [→](#split-panel-outfit-change-sheet-ghost-mannequin--identity-panel)
- Crowds: a single-character reference makes a clone army — build a multi-character lineup and declare it a "VARIETY reference" [→](#variety-sheets--crowds-without-clones)
- Character Anchor Block = 10 per-shot attributes (identity, screen position, depth layer, frame occupancy, orientation, pose, gaze, contact points, state lock, expression) [→](#character-anchor-block)
- One Soul ID sheet PER character state — 5 transformation stages = 5 distinct sheets; the prompt names the stage [→](#multi-form-state-tracking)
- Micro-expression presets: 9 core + 10 extended [→](#core-set)
- Cinema Studio: identity goes in the @ Element definition, motion goes in the prompt field [→](#beforeafter-examples)
- Soul Cast is Business/Team plans only; 8 parameter categories incl. 12 Archetypes, Budget $10M–$500M, Era 1900s–2020s [→](#cinema-studio-30-soul-cast-businessteam-plan)
- Soul Cast specs: up to 4K (Character/Location modes) / 2K (General); batch 1 or 10; 0.125 credits per image [→](#30-soul-cast-specs)
- Use 2–3 reference shots (frontal, 3/4, side); if features drift, use the character sheet as @Image1 [→](#character-consistency-best-practices)
- Soul Cinema is the default CS 3.0/3.5 image-mode model — single-step, ~0.125 credits/image [→](#soul-cinema-as-the-cs-3035-default-image-model)
- Studio-feeling output is an intermediate, not a final — re-pass through Soul Cinema with grade, directional lighting, lens character; the result is a derived look frame, never the identity base or a reference plate [→](#studio-look-vs-cinematic-look--soul-cinema-as-the-re-pass)
- Skip Soul ID for single shots or when you want maximum creative variation [→](#when-to-use-soul-id)
- Plasticky face in wide shots: crop the face from a closer-shot panel and replace it in post [→](#face-from-wide-shot-workaround)
- Casting a REAL person: the sheet alone returns a lookalike — erase the head on the body panels and paste their actual photo into the portrait panel [→](#the-hybrid-sheet--casting-a-real-person)
- Run the same sheet prompt through 2–3 image models and compare before locking; the deciding axis changes per character [→](#pick-the-sheet-model-per-job-not-per-project)


## What Is Soul ID?

Soul ID is Higgsfield's character consistency system. Create a character reference once,
then reuse it across unlimited generations — different scenes, angles, lighting, and
actions — while the face and core appearance remain consistent.

---

## How It Works

1. **Create a Soul ID** — Upload a reference image or generate one using Soul 2.0
2. **The platform stores the character** — assigns it an ID
3. **Reference in future prompts** — "using Soul ID character [name/reference]"
4. **Character stays consistent** — face, skin tone, basic features carry across generations

---

## When to Use Soul ID

✅ You're building a multi-shot sequence with the same character
✅ You're creating a short film / story with a recurring protagonist
✅ You're making an AI influencer or brand mascot
✅ You want consistent faces across a product ad campaign
✅ You're doing a multi-scene action sequence and need the hero to look the same

❌ Don't use if you only need one shot — overkill for single generations
❌ Don't use if you want maximum creative variation — consistency limits style range

---

## Prompting With Soul ID

When a Soul ID character is active, your prompt should:

**1. Reference the character simply:**
```
The Soul ID character walks through a crowded Tokyo street at night.
```

**2. Describe what changes — not what the character looks like:**
```
The Soul ID character now wears a formal black suit. She stands at a podium,
addressing a conference room. Camera: Dolly In toward her face.
Style: Cinematic, cool corporate lighting, 16:9.
```

**3. You can change clothing, setting, expression:**
```
The Soul ID character is now in a red dress, dancing alone in a ballroom.
Camera: 360 Orbit.
Style: Cinematic, warm golden chandelier light.
```

**Key rule:** Don't re-describe the face or core features — the Soul ID handles that.
Only describe what is *different* from the base character.

---

## Identity vs. Motion Separation — Hard Rule

When Soul ID is active, **every prompt MUST be split into two blocks**. This is the
single most important rule for preventing identity drift.

### Identity Block — Static descriptors only
Contains: face features, clothing, body type, distinguishing marks, color palette.
Does NOT contain: any motion, camera, speed, or temporal language.

### Motion Block — Temporal and camera only
Contains: camera movement, action choreography, speed, environmental changes.
Does NOT contain: any character appearance repetition.

### Before/After Examples

**Example 1 — Action scene:**

❌ **Mixed (bad) — causes identity drift:**
```
A tall woman with green eyes and freckles in a leather jacket sprints through
a warehouse while the camera tracks her and her green eyes flash with determination
and her freckles catch the fluorescent light as she vaults over a railing.
```
Face morphs mid-clip because the model re-reads face descriptors while processing motion.

✅ **Separated (good) — identity stays locked:**

**Identity Block:**
```
The Soul ID character — tall build, green eyes, light freckles across the nose
and cheeks, wearing a fitted black leather jacket, dark jeans.
```

**Motion Block:**
```
She sprints through a dimly lit warehouse, vaults over a metal railing
without breaking stride.
Camera: Action Run — low behind her, matching pace.
Fluorescent lights flicker overhead.
Style: Cinematic, cold industrial blue, high contrast. 16:9.
```

---

**Example 2 — Emotional close-up:**

❌ **Mixed (bad) — face warps during camera move:**
```
A weathered man with deep wrinkles and sad brown eyes wearing a grey wool coat
sits on a park bench as the camera slowly dollies in on his wrinkled face and
sad brown eyes while autumn leaves drift past his grey coat.
```

✅ **Separated (good) — face stays sharp:**

**Identity Block:**
```
The Soul ID character — grey-haired man, deep wrinkles, warm brown eyes,
wearing a heavy grey wool coat, brown leather gloves.
```

**Motion Block:**
```
He sits on a park bench, hands folded in his lap, staring at the ground.
A single autumn leaf drifts into frame and lands on the bench beside him.
Camera: slow Dolly In toward his face.
Style: Cinematic. Overcast diffused light, muted earth tones. 16:9.
```

---

**Example 3 — Cinema Studio (@ Elements):**

❌ **Mixed (bad) — identity in the prompt field:**
```
@Sarah with her dark curly hair and tattoo sleeve walks into the bar.
```

✅ **Separated (good) — identity in the Element, motion in the prompt:**

**@ Element definition (set in Cinema Studio UI):**
```
@Sarah: dark curly hair, tattoo sleeve on left arm, wearing a vintage band tee.
```

**Prompt field:**
```
@Sarah pushes open the door and steps inside. She scans the room, then walks
to the far end of the bar. The bartender nods.
```

### Which descriptors belong where

| Identity Block | Motion Block |
|---------------|-------------|
| Face shape, skin tone, eye color | Camera movement name |
| Hair style, color, length | Action verbs (runs, turns, sits) |
| Body type, height, build | Environmental motion (wind, rain, lights) |
| Clothing, accessories, jewelry | Speed and timing cues |
| Scars, tattoos, distinguishing marks | Atmospheric changes (light shifts, fog) |
| Color palette of the character | Style and color grade of the scene |

---

## Creating a Strong Soul ID Reference

The quality of your Soul ID reference image determines consistency quality.

**For best results:**
- Use a **front-facing or 3/4 angle** portrait — full face visible
- **Even lighting** — avoid harsh shadows obscuring features
- **Neutral to slight expression** — smile is fine, extreme emotion limits flexibility
- **Clear image** — no blur, no obstruction, no glasses if avoidable
- **Solo subject** — no other people in the reference frame

**Image models to generate your Soul ID reference:**
- **Soul 2.0** — best for fashion-forward, high-aesthetic characters
- **Nano Banana Pro** — best for maximum photorealistic sharpness
- **Seedream 4.5** — good for a range of styles

---

## A sheet is not a menu — everything on it is a request

`[FIELD — Higgsfield Studio, ZEPHYR breakdown, 2026-08-06]` The intuitive way to build a
sheet is to put *everything* on it — every weapon, every state, the mechanism drawn open —
and then reference only the parts you need per shot. **That is not how the model reads it.
If it sees a detail, it will try to show it.**

The reported failure: a mecha sheet included the cockpit hatch in its open state. The model
**prioritised the open hatch over the subject's standard look**, so most generations came
back with the hatch open when it should have been shut — or with the open and closed
versions colliding and deforming the whole design. The main body being larger on the sheet
did not help; presence beat proportion.

The fix is more sheets, not a richer one:

- **Erase states that are not the default** from the base sheet, and be especially careful
  with anything retractable, hinged, or deployable.
- **Build a separate sheet per scenario**, even when the differences look minor. Attach the
  extended-weapon sheet **only in the shots where it is actually extended**.
- **Better still, give a mechanism its own close-up as a separate input** when the shot has
  to show how it works, so it gets focus instead of competing with the full figure.

> **Captions on a sheet do almost nothing for video.** A little label under a detail does
> not teach the model to operate it — you still have to describe the whole operation in the
> prompt. The model will not reason *"retractable blade, I know how to stage that"*; every
> mechanism gets written out as physical action in the shot that uses it.

This is the sheet-side twin of § Variety Sheets: the question is never "what could this
sheet contain" but "what will the model be asked to render from it."

## The Untouched Base — build a character in two passes

`[FIELD — Higgsfield Studio, ONEIRIC + ADILIADA breakdowns, 2026-08-13]` A character is
built in two passes with two models, and the discipline is in what happens *after*:

1. **The face pass** makes the identity plate — generated in **close-up**, so the model
   captures identity at maximum detail. That close-up is the anchor every later asset of
   the character is checked against.
2. **The looks pass** builds full-figure wardrobe — costume, materials, silhouette — fitted
   to the already-locked face.

The two are then assembled into a sheet **with one hard condition: the original close-up
portrait is never run through a model again.** Assembly happens in editing tools *around*
it. Every state change — a scar, a haircut, dirt, a wound, a new wardrobe piece — is
integrated point by point with masks, **without touching the base**.

**Why it matters:** the base image stays the same *pixels*, so identity and the skin texture
that carries it survive every later version of the character. This is the structural answer
to the drift documented in § Two-Tool Refinement Pipeline, where each successive model pass
softens texture toward plastic — the base never takes another pass, so it never softens.

> **How the one-line model fix composes with it** (`../shared/house-rulings.md` P2-3). The
> field fix for a flawed sheet — attach it to Nano Banana 2 with one sentence
> (`../higgsfield-seedance-2-5/VFX-PIPELINE.md` § Stage 1) — is a legal way to *make* the
> point edit. On the base, what it returns is a donor: mask the changed region back onto the
> untouched original, as `../higgsfield-seedance/HELL-GRIND.md` also requires. Whether one
> full pass alone measurably softens a sheet is unmeasured here; the mask is the default
> because it costs minutes, while a softened base is paid for in every shot that reads it.

### Hold the face, change everything else

The same rule scales to alternate versions of one character — a different era, a different
universe, hero in one world and villain in the next. **A new version is a new look, not a
new person:** wardrobe, makeup, hair, scars and damage all change, and the face stays the
same set of pixels. That is what keeps an alternate version still reading as the same
person, which is the whole difficulty of the job — living between "make them different" and
"make them the same".

A corollary worth stating, because it is where sheets quietly rot: **a new state is a new
asset with a new name, never an overwrite.** A character in the common room and the same
character in a hospital bed are two assets of one man.

## The Reference Plate — the two axes

`[EMPIRICAL — Joey character-builder / banana-pro-director 3.0 skills (2026-08-16), re-derived 2026-08-22]`
Photoreal character work runs two things that sound like one thing and are not. Separating
them is the single most useful idea in plate building, because "photorealistic" sounds like
it means both and only one of them belongs on a reference.

**Axis 1 — biological realism: fully ON.** The subject must read as a real living person:
pore texture, peach fuzz at jaw and hairline, subsurface scattering, hair strand by strand
with flyaways, fabric with real weave and drape, metal with real surface, eyes with depth
and moisture. This never comes off.

**Axis 2 — photographic capture behaviour: OFF on every plate.** A plate is not a photograph
of a lit set. No key direction, no shadow side, no cast or contact shadow, no falloff on the
background, no spill, no bokeh, no depth-of-field falloff, no vignette, no flare, no haze.

**Why Axis 2 is off:** these are *references*, not finished frames. Any lighting baked into
a plate — a cheek triangle, a nose shadow, a contact shadow under the feet, a warm bleed on
the backdrop — is inherited and amplified by every downstream generation that reads it, and
it fights whatever lighting the actual scene wants. **The plate carries zero lighting; the
scene prompt does all the lighting later.**

> **The trap.** Writing *"photographed on a real camera by a real photographer on a real
> set"* into a plate prompt switches Axis 2 **on** along with Axis 1 — and Axis 2 is exactly
> what poisons a reference. The subject should look like a real person, rendered flat,
> against nothing.

The one capture phrase that survives: `Photographed on a 50mm prime, even sharpness[, soft
natural film grain]. Photographed not generated.` — the focal length is named in plain words
with no aperture, no bokeh and no falloff attached, so it buys the anti-AI-uniformity signal
without switching on capture behaviour. **The bracketed grain clause is an open question, not
part of the settled phrase** — see the box below.

> **The grain clause is contested — OPEN, no default** (`../shared/house-rulings.md` P2-4).
> This source keeps *soft natural film grain* as part of the anti-uniformity signal.
> `../higgsfield-seedance/HELL-GRIND.md` § The character sheet `[OFFICIAL — Hell Grind brief]`
> reports the opposite: bake film grain into the sheet and the character carries that look
> into every scene and stops reacting to new light. Both failures are inherited by every shot
> that reads the plate — baked grain cannot be removed per shot; a plate that reads
> AI-uniform, plastic skin included, softens every shot the same way (§ The Untouched Base
> guards the same texture) — so neither is clearly the cheaper failure, and nothing here
> measures it. What both sides share: Axis-1 skin detail stays fully on (Hell Grind's own
> sheet asks for "real skin with visible pores, no retouch"). Decide per project, pin the
> choice once, and never vary it across one character's plates.

### The background is a FIELD, not a ROOM

The distinction most often lost. A photographed seamless is a *physical surface* — it takes
light, it falls off, it catches spill, it holds the subject's shadow, it has a floor the
subject stands on. **A plate background is none of that.** It is a flat uniform colour field
with nothing behind the subject at all: no surface, no floor, no wall, no corner, no seam,
no horizon, no plane the subject makes contact with. The subject does not stand *on*
anything and does not stand *in front of* anything, and nothing the subject does affects the
field.

### The flattering-realism ceiling

Full skin realism is always on — but realism never means unflattering. No acne, blemishes,
prominent spots, unrequested scarring, cratered pores, or aggressive detail that reads
clinical. The texture is fine, soft, even, natural. **Matte is the anti-plastic lever;
fine-and-even is the flattering lever, and both run together.** Where they conflict, resolve
toward flattering — a face should always look good.

### Prompt economy — lean prompts hold faces better

This runs counter to instinct. When strong references are attached, **the references carry
the identity load, and the prompt's job is to say what to DO with that identity in this
image.** Heavy visual description layered on top of a strong reference creates a
double-weight prompt that dilutes the direction the model actually needs from the text.

- Identify subjects by a **short distinguishing handle** — *"the woman with the deep
  red-burgundy hair"* — not a paragraph re-describing bone structure the attached plate
  already shows.
- Put the load on what the prompt **uniquely** communicates: composition, framing, pose,
  expression, what the hands are doing, wardrobe not already in a reference.
- **Drop identity description that the reference already carries**, unless it is
  load-bearing for this specific image.
- The model reads the front of the prompt most heavily — put composition and pose there
  rather than burying them under description.

**Rule of thumb:** if a sentence re-describes something already visible in an attached
reference, cut it unless the composition depends on it. **The exception is the first plate**
— a face lock has no reference to lean on, it *is* the reference, and it gets the longest,
most specific description of anything in this file. Everything after it gets leaner.

When two or more references are attached, **say what each one carries** so the model does
not average them: *"face, bone structure and skin tone come from the character reference;
wardrobe and accessories come from the look reference."*

> Lean prompts next to a reference are one side of an **open** question for *video*
> (`../shared/house-rulings.md` P1-1): Higgsfield's feature-film pipeline pastes the full
> descriptor, word for word, beside the reference (`../higgsfield-seedance/HELL-GRIND.md`
> § The core problem). For image plates this section's rule stands; for a multi-shot video
> pipeline, read the ruling first.

---

## Character Sheet Creation

A **character sheet** is a multi-angle reference image showing the same character from
several viewpoints — typically front, 3/4, side profile, and back. It gives the model
comprehensive geometry to work from and dramatically improves consistency.

**Two-image floor per character** [DEMO — Seedance-4K film tutorial, 2026-07]:
never hand a video model a character on a single image. The minimum is **one
clear face view + one full body** — in the tutorial's words, "so Seedance
doesn't have to guess." Everything below builds upward from that floor.

**Background:** put sheets on **neutral grey**, not white or black. The law is stated once —
the shade range, one pinned hex per project, the three reasons sources give for it, and the
contact-shadow disagreement — in `../../templates/ad-asset-prep.md` § Design for win rate.
For a plate that will be read as a reference, the grey is a flat *field*, not a lit
seamless (§ The Reference Plate — the two axes).

**How to create a character sheet:**
1. Generate your character in Cinema Studio using your preferred optical stack
2. Use **Grid Generation (2×2 or 4×4)** to produce multiple variations
3. Alternatively, use **3D Mode (Gaussian splatting)** to orbit a single generation and
   capture front, side, and 3/4 angles
4. Arrange the best angles into a single composite reference image
5. Upload as your Soul ID reference

**What to include on a character sheet:**
- **Front face** — neutral expression, even lighting
- **3/4 angle** — shows depth of facial features
- **Side profile** — nose, jaw, ear structure
- **Full body** (optional) — posture, costume, proportions
- **Embedded prop sheets** (optional) — bake recurring character
  props directly into a character-sheet panel. Higgsfield image
  generation handles multi-element character images well, so prop
  continuity often holds without a separate prop sheet. For props
  that don't hold this way, see § Tricky-Prop Sheets below.

**Prompt pattern to generate character sheet content:**
```
Front-facing portrait of [character description], neutral expression, even studio lighting,
clean background. Head and shoulders visible.
```
Then use 3D Mode to orbit and capture additional angles from the same generation.

**Why it matters:** A multi-angle character sheet gives Soul ID far more geometry data
than a single photo. This translates directly into better consistency across extreme
angle changes, action shots, and profile views.

### The Hybrid Sheet — Casting a REAL Person

Everything above assumes the character is *invented*. Casting a real person —
a client, a friend, the couple in a wedding film — is a different problem, and
the sheet pipeline alone does not solve it [DEMO — Higgsfield "AI Love Stories"
tutorial, 2026-08]. Feed someone's photos in as references and the sheet comes
back as **a lookalike actor, not the actual person**: costume and body land,
the face is a near-miss. It is the kind of near-miss the subject's own family
spots instantly and nobody else notices, which makes it the worst kind.

Note what this is NOT. § Face-from-Wide-Shot Workaround below fixes *plastic AI
faces* by cropping a face from a closer generated panel into a wider one — a
quality repair, generated pixels throughout. This fixes *identity*, and the
pixels come from a camera.

**The hybrid, as demonstrated:**

1. Generate the sheet normally. Keep it for what it is genuinely good at —
   costume texture, wear, silhouette, body, the panel geometry.
2. **Erase the head on the full-body panels.** Leave them headless. The
   generated face is the part that was wrong; deleting it stops it competing
   (the one-readable-face law: `../../templates/ad-asset-prep.md` § Design for
   win rate).
3. **Paste the person's real photograph into the portrait panel.** That panel
   is now photographic, not generated.
4. Ride the composite as the character reference.

**Why it works:** the portrait panel is where a video model reads identity, and
it is now a real face rather than an approximation of one. The full-body panels
still carry wardrobe and proportion, which is all they were ever needed for —
and a headless panel cannot contribute a wrong face, so the composite has
exactly one face in it and that face is correct.

**Constraints, and they are not optional.** This puts a real, identifiable
person into a generation pipeline. Have their permission for this specific
use, keep the source photos out of anything you publish, and do not use the
technique on someone who has not agreed to it. The dating, wedding and gift
work this method is aimed at is exactly the context where consent is easy to
get and easy to skip.

### Pick the Sheet Model per JOB, Not per Project

The same sheet prompt through three image models does not produce three
qualities of the same thing — it produces three different strengths, and the
right answer is per-character [DEMO — Higgsfield "AI Love Stories" tutorial,
2026-08]. In that run, from one prompt across Seedream 5.0 Pro, GPT Image 2 and
Nano Banana:

| Model | What it won on, in that comparison |
|---|---|
| Seedream 5.0 Pro | costume **texture and wear**, and consistency of the costume across all three panels |
| GPT Image 2 | **curly hair** — full, natural, and identical from every angle; the others could not hold it |

The AI-vs-VFX build routes "clothing, wardrobe changes, branded garments" to GPT Image 2
(`../higgsfield-seedance-2-5/VFX-PIPELINE.md` § Stage 1); this comparison picked Seedream 5.0
Pro for costume texture on a sheet generated from scratch. The build does not split by job —
reading the two as *edits on an existing sheet* vs *texture from scratch* is a `[HOUSE]`
inference that would let both stand — not a default. Two productions, no measurement here;
OPEN (`../shared/house-rulings.md` P3-2), and the method below decides per character.

[UNPROVEN HERE] — one production's comparison, on two characters. Treat the
*method* as the finding, not the table: **run the same sheet prompt through
two or three models and compare before locking**, because the axis that decides
it is whatever your character is hardest to render (hair, wardrobe wear, skin,
a signature prop), and that axis changes per character. Sheets are cheap
relative to the shots that depend on them; a wrong lock is paid for in every
later generation.

Model specs and current pricing: `../../image-models.md`.

### Single-prompt 6-panel character sheet (3×2 grid)

An alternative to the multi-step assembly above is generating
the entire character sheet in **one prompt → one 16:9 image →
3×2 grid with six labeled panels**. Same character described
once; identity stays maximally locked across all six panels
because the generation pass is single. Prefer this for Soul ID
reference work when the image model supports a 16:9 grid layout
(Nano Banana Pro and similar grid-capable models).

The six panels in canonical order:

- **Panel 1 — Front body:** straight-on neutral stance, full
  styling visible head-to-toe
- **Panel 2 — 3/4 turn:** body angled ~30° from camera, weight
  on back hip
- **Panel 3 — Back body:** straight back view, hair fall and
  accessory details from behind
- **Panel 4 — Waist-up portrait:** head, shoulders, upper torso
- **Panel 5 — Hands detail close-up:** both hands forward, ring
  stack, nail finish, any held prop
- **Panel 6 — Face detail close-up:** tight crop from collarbone
  up, earrings, lips, skin texture, eyes

**Prompt pattern** — identity described once at the opening,
followed by panel position labels with what's different per
panel (stance, framing, focus). Close with: "Identical character
identity locked across all six panels. Uniform studio backdrop
and lighting across all six panels."

**Why single-prompt over multi-step:** the multi-step assembly
above (Grid Generation + 3D Mode + composite) produces a sheet
from multiple independent generations — identity can drift
panel-to-panel even with a strong reference. The single-prompt
3×2 grid keeps identity locked because all six panels render
together in one pass.

### Split-Panel Outfit-Change Sheet (ghost-mannequin + identity panel)

A two-panel sheet pattern for **re-dressing an existing character without
touching identity** [DEMO — Seedance-4K film tutorial, 2026-07] — the
tutorial used it to put its lead into a new Y2K outfit:

- **LEFT panel — outfit only, ghost-mannequin:** the full new outfit as
  floating garments styled as worn — invisible body, no person, no head.
  Describe the clothes in full here (cut, fabric, graphics, accessories,
  footwear); this panel owns the wardrobe.
- **RIGHT panel — identity only:** a large head-and-shoulders close-up from
  the existing character reference, declared **"face matches input 100%"** —
  same identity, features, hair, skin, no drift. This panel owns the face;
  wardrobe appears only as the upper edge of the LEFT panel's outfit.
- **Clear vertical divide, neutral grey studio backdrop, even soft light**
  across both panels. (The grey law — shade range, one pinned hex per project —
  is stated once in `../../templates/ad-asset-prep.md` § Design for win rate.)

The split gives the video model one panel to read for *what they wear* and
one for *who they are*, so the outfit change can't pull the face with it.
Registered as a single Element, the sheet carries both. Complements § Multi-
Form State Tracking below — a wardrobe state is a state like any other and
gets its own sheet.

---

## Character Anchor Block

Where § Character Sheet Creation builds the multi-angle identity
reference that goes into Soul ID, the **Character Anchor Block**
is the per-shot prompt structure that locks how that character
appears IN a specific shot. The character sheet is build-time; the
anchor block is shot-time.

A complete anchor block names, per character in frame, ten
attributes:

1. **Identity** — which character this is (matches a Soul ID
   handle when references are present)
2. **Screen position** — qualitative anchor + percentage notation
   paired per `../higgsfield-seedance/higgsfield-seedance.md` § Frame Coordinate
   System
3. **Depth layer** — foreground / midground / background
4. **Frame occupancy** — % of frame area the character fills
5. **Body orientation** — direction the character faces (toward
   camera, away, profile-left, profile-right, three-quarter)
6. **Pose** — current physical configuration (standing, seated,
   leaning, mid-stride)
7. **Gaze direction** — where the character is looking, named
   either by frame-position or by another subject (`looking at
   Character B`)
8. **Contact points** — what physical surface or object the
   character is grounded against
9. **State lock** — current emotional or physical state (calm,
   exhausted, injured, soaked, in motion) — see § Multi-Form State
   Tracking for state-across-scenes discipline
10. **Facial expression** — specific emotional register (composed,
    fearful, smiling small, gritted teeth)

The block sits before the Dynamic Description in the Seedance
output format and feeds a Spatial Layout Block when multiple
characters share frame (see `../higgsfield-seedance/higgsfield-seedance.md`
§ Spatial Layout Block for the multi-character extension).

### Multi-Form State Tracking

When a character changes state across the project — wounds from a
fight scene that persist into the next scene, a costume change
midway through, a transformation across multiple stages — generate
a **separate anchor sheet per state**. Don't rely on the base
character sheet plus prompt-text descriptions to track the
difference; the model loses the state under iteration pressure.

The discipline is what film production calls **script supervising**:
every shot tracks which version of the character it should match. A
character with five stages (initial → fight-injuries → partially-
transformed → almost-fully → completely-transformed) gets five
distinct Soul ID sheets, one per stage. The shot list references
the matching sheet by name; the prompt names the stage in the
identity block.

The cost is one character-sheet generation pass per state; the
payoff is that no shot opens a continuity bug that has to be caught
at frame-review time (see `../higgsfield-seedance/FAILURE-MODES.md`
§ Frame-level review is mandatory).

### Face-from-Wide-Shot Workaround

In wide shots the face on a character-sheet panel often reads as
plasticky — the model deprioritizes facial detail when most of the
frame is body or environment. The workaround: render the wide shot,
then crop the **face** from a **closer shot** (medium-up, shoulders-
up, head-and-shoulders) and replace the wide-shot face with the
cropped one in post.

This is a character-sheet construction technique, not a generation
technique. Keep one closer-shot panel in the character sheet
specifically for this purpose — the face you'd cut and paste back
into wide shots that need it.

### Tricky-Prop Sheets

Some props don't generate consistently from a single reference panel
— a monster claw the model keeps rendering as a sword, a hand-prop
that defaults to a generic shape, an accessory that can't stay
continuous across shots. For these, build a **separate prop sheet**
alongside the character sheet:

- **Inside view** — interior structure or assembly detail
- **Outside view** — silhouette and surface
- **State variations** — open / closed / extended / grasped /
  combat-engaged, as the prop's narrative requires

The inverse pattern to the **Embedded prop sheets** bullet in
§ Character Sheet Creation above — embedded works for props that
generate cleanly; separate prop sheets are the fallback for props
that don't.

---

## Two-Tool Refinement Pipeline

For high-investment characters — leads who carry many shots in a
project — initial generation in **Soul Cinema** plus refinement
editing in **GPT Image 2** produces stronger anchor sheets than
either tool alone. Soul Cinema is the Higgsfield first-pass image
surface (high-volume batch generation against the character
description); GPT Image 2 is a third-party (OpenAI) edit surface
that preserves existing image details — particularly facial
geometry — when modifying outfits, accessories, lighting, or
background elements.

The split is by task:

- **Soul Cinema** — generate the initial character look across pose,
  expression, and lighting variations. Higher-volume; the model
  batches well.
- **GPT Image 2** — edit selected Soul Cinema outputs to refine
  costume, swap accessories, adjust lighting, or extend the sheet
  with state variations. Better preservation of the face under edit
  pressure.

**Scope** (`../shared/house-rulings.md` P2-3). An edit pass is a second full pass. On the
character's **identity base** — the close-up face plate every shot reads — make the edit, then
**mask only the changed region back onto the untouched original** (§ Anti-"slop" realism
composite below; § The Untouched Base). A whole-frame edit such as *adjust lighting* has no
region to mask back, and lighting baked into a reference plate is what § The Reference Plate
keeps off: it belongs on a derived look frame, never on the identity base.

When to reach for both tools: the character will appear in tens of
shots and is worth front-loading iteration cost into. A planning
anchor from a Higgsfield-team production — the lead character of
the 90-minute Cannes feature absorbed ~600 Soul Cinema generations
plus ~200 GPT Image 2 generations before any narrative shot
generation began (see `../../production-benchmarks.md` § Per-
character iteration anchor for the full breakdown).

When to stick with one tool: characters appearing in only a handful
of shots don't justify the two-tool overhead; a single Soul Cinema
pass suffices.

### Anti-"slop" realism composite (the fast manual variant)

Every GPT Image 2 edit softens Soul Cinema's skin texture toward flat,
plastic "AI slop" — the face loses the pore-level realism that made the
Soul pass worth doing. A Soul Cinema **Re-Pass** (re-generate the edited
result back through Soul Cinema) is one fix; a **layer-mask composite** in
any photo editor is the faster manual variant, and keeps the original
face untouched:

1. Generate the outfit/accessory edit in **GPT Image 2** (this is what
   softens the skin).
2. Stack two layers: the **original high-detail Soul Cinema shot on top**,
   the **GPT-edited version underneath**.
3. **Mask out only the changed region** (the old outfit) on the top layer,
   so the new outfit shows through from below.
4. Result: face, skin, and background stay Soul-grade; only the outfit
   comes from the edit.

Use the Re-Pass when you want one clean re-generated sheet; use the
layer-mask composite when you must preserve the exact original face and
only graft in the edited region. On a character's **identity base** only the
composite is legal — the base close-up never takes another pass (§ The
Untouched Base); the Re-Pass is for derived sheets whose own base stays
untouched. Complements the "generate individually +
Photoshop composite" note in `../../image-models.md`. Cross-linked from
`../../templates/ad-asset-prep.md` § Preserve realism after an edit.

---

## Micro-Expressions — Nuanced Performance Direction

Use these facial performance directions to add emotional depth to Soul ID characters.
Combine with Soul Cast or character prompting for precise actor-level control.

> **For muscle-level control** — when a named expression below is too coarse and
> you need the specific facial muscles (a forced vs. genuine smile, a mixed or
> uncanny expression, AU-per-beat dialogue acting) — see
> `../higgsfield-facs/higgsfield-facs.md` (FACS Action Unit codes). Each named expression
> here decomposes to an AU combination; FACS is the precise-control layer beneath.

### Core Set

| Name | Description | Best for |
|------|-------------|----------|
| **Deadpan Neutral** | Flat affect, no visible emotion, mask-like stillness | Thriller, interrogation, AI/android characters |
| **Fierce Focus** | Intense locked gaze, brow slightly lowered, total attention | Action, competition, confrontation |
| **Subtle Arrogance** | Chin slightly raised, half-lidded eyes, faint smirk | Villain intros, power dynamics, fashion |
| **Candid Profile** | Unposed side angle, natural and unaware of camera | Documentary, street photography, slice-of-life |
| **Post-Workout Fatigue** | Heavy lids, parted lips, light sheen of sweat, relaxed muscles | Fitness, aftermath, exhaustion scenes |
| **Predator Glare** | Unblinking stare, head slightly lowered, eyes locked forward | Horror, thriller, intimidation |
| **Sunblind Squint** | Eyes narrowed against bright light, slight grimace | Outdoor scenes, desert, beach, golden hour |
| **Total Dissociation** | Thousand-yard stare, eyes unfocused, emotionally absent | Trauma, shock, psychological drama |
| **Controlled Breath** | Lips slightly parted, nostrils flared, deliberate calm | Pre-action tension, meditation, recovery |

### Extended Set

| Name | Description | Best for |
|------|-------------|----------|
| **Suppressed Smile** | Fighting back a grin, corner of mouth twitching | Comedy, secret joy, romantic tension |
| **Quiet Devastation** | Eyes glassy, jaw tight, holding it together | Drama, grief, emotional climax |
| **Wary Recognition** | Eyes widen slightly, head tilts back a fraction | Reunion, suspicion, plot twist reaction |
| **Nervous Composure** | Calm face but swallowing, micro-tension in jaw | Interviews, lies, high-stakes poker |
| **Cold Calculation** | Eyes scanning, no emotional leakage, clinical | Villain strategy, heist planning, espionage |
| **Bitter Amusement** | One-sided smirk, eyes not smiling | Cynicism, dark humor, betrayal aftermath |
| **Exhausted Relief** | Eyes closing, shoulders dropping, breath release | Survival, rescue, end of ordeal |
| **Frozen Shock** | Mouth slightly open, eyes fixed, body still | Jump scares, bad news, sudden revelation |
| **Simmering Rage** | Clenched jaw, flared nostrils, steady stare | Confrontation, injustice, slow burn tension |
| **Vulnerable Openness** | Soft eyes, slightly parted lips, unguarded | Romance, confession, emotional honesty |

---

## Multi-Character Consistency

If you need multiple consistent characters in the same scene:

```
Shot 1 — establish both:
The Soul ID character [Character A] and a second character [Character B, describe
appearance] face each other across a table. Camera: Arc slowly around them.

Shot 2 — reference both:
The Soul ID character [A] slides a folder across the table.
[Character B] opens it, expression shifting from confusion to realization.
Camera: Dolly In toward [B's] face.
```

Note: Higgsfield can hold multiple Soul IDs. Reference each clearly in the prompt.

---

## Variety Sheets — Crowds Without Clones

Everything above optimizes for **one** identity locked tight. Point that
machinery at a crowd and it backfires: **a single-character reference makes a
clone army** — every soldier, extra, and passer-by renders as the same person
[DEMO — Seedance-4K film tutorial, 2026-07]. The tutorial's canonical
before/after: an elf army generated from one elf reference came back as
identical clones; the fix was a new sheet plus one label change.

**The fix — a variety lineup sheet:**

1. **Build one sheet with several DISTINCT characters side by side** — the
   tutorial used four fully-specified elves in a full-body lineup on neutral
   grey: different genders, hair colors (blonde / dark / auburn / silver),
   builds, and armor tones (silver / gold / rose). Each lineup member is
   individually described; sameness anywhere in the sheet becomes sameness
   in the crowd.
2. **Declare it a "VARIETY reference" in the video prompt** — not an identity
   lock. Tutorial pattern: `@elf — VARIETY reference for the elven army: a
   sheet of FOUR different elves … the army is a varied host drawn from these
   four types, every elf unique, no two alike.` Reinforce in the positive
   locks: "a VARIED host built from the four types in @elf."

**The role split:** `100% matches the reference` locks ONE character's
identity; `VARIETY reference` tells the model to treat the sheet as a
*population sample* to interpolate a diverse crowd from. Use identity locks
for leads, a variety sheet for the crowd behind them — both can be Elements
in the same prompt. (Reference-role vocabulary:
`../higgsfield-seedance/higgsfield-seedance.md` § Reference Roles.)

**Pairs with the empty-plate rule for locations — but that rule has a
condition, and it used to be stated here without one.** The default still
holds: generate the location with no people and let the video model own the
crowd from the variety sheet (`../../templates/ad-asset-prep.md` § Location
plates). It gives you one plate that serves every shot, and the crowd stays
directable per shot.

It **inverts on a location whose crowd IS the location** [DEMO — Higgsfield
"AI Love Stories" tutorial, 2026-08]. A night carnival square kept breaking
from an empty plate — the model had to invent a packed festival throng from
prose on every take, and the takes disagreed with each other. Generating the
square **already alive with the costumed crowd**, baked into the location
asset, fixed it, and the reported side effect is the tell: *"the prompt stayed
clean and simple."* The crowd stopped being something every shot prompt had to
re-specify.

**Which rule applies — decide on the plate, before the shots:**

| Empty plate + variety sheet | Crowd baked into the plate |
|---|---|
| the crowd is *staffage* — passers-by, background traffic | the crowd **is the set**: a festival, a packed arena, a market at full tilt |
| headcount and behaviour change shot to shot | the same dense mass in every shot of the scene |
| you need the crowd directable ("they scatter") | the crowd is scenery and never takes direction |
| density is low-to-medium | density is so high that prose cannot specify it without bloating every prompt |

The test that decides it: **write the crowd out in prose and see how long it
is.** If specifying it costs a paragraph in every shot prompt, that paragraph
belongs in the location asset instead. And verify before committing the scene —
that production ran one cheap test generation purely to see whether the baked
crowd held, which is the right order.

[UNPROVEN HERE] — one production, one location type. What is certainly true is
that the unconditional form of this rule was wrong.

---

## AI Influencer Workflow

Soul ID is the foundation of Higgsfield's AI Influencer Studio feature.

**Workflow:**
1. Create Soul ID from a high-quality portrait (generated or uploaded)
2. Generate images of the character in different outfits/settings
3. Animate using image-to-video with motion presets
4. Use Lipsync Studio to add speech if needed
5. Chain shots together for a full content series

**Prompt pattern for influencer content:**
```
The Soul ID character [name] is in a modern kitchen at golden hour.
She holds a coffee mug, steam rising. She looks directly at camera with a warm smile.
Camera: slight Dolly In. Style: Lifestyle, warm tones, 9:16 vertical.
```

---

> **Negative constraints:** For face/identity artifacts (face morphing, identity drift,
> character swap, plastic skin) and their prevention phrases, see
> `../shared/negative-constraints.md` — Face/Identity Artifacts section.

---

## Cinema Studio 3.0 Soul Cast (Business/Team Plan)

> **Plan requirement:** Cinema Studio 3.0 Soul Cast is available exclusively on **Business and Team plans**.

Cinema Studio 3.0 carries over Soul Cast's 8 parameter categories from 2.5:

| Category | Options |
|----------|---------|
| Genre | General, Action, Horror, Comedy, Noir, Drama, Epic |
| Budget | $10M – $500M (affects production value aesthetic) |
| Era | 1900s – 2020s (decade increments) |
| Archetype | Innocent, Everyman, Hero, Caregiver, Explorer, Rebel, Lover, Creator, Jester, Sage, Magician, Ruler (12 options) |
| Identity | Gender, race, age |
| Physical Appearance | Build, height, eye color, hair style, hair texture, hair color, facial hair |
| Details | Scars, tattoos, accessories, distinguishing marks |
| Outfit | Clothing, materials, colors |

### 3.0 Soul Cast Modes

| Mode | Purpose | Output |
|------|---------|--------|
| General | Open-ended character generation | Character image |
| Character | Focused character creation with detailed parameters | Character image |
| Location | Environment/setting generation | Location image |

### 3.0 Soul Cast Specs

- Image resolution: up to 4K (Character/Location modes) · up to 2K (General mode)
- Batch size: 1 or 10
- Generation cost: 0.125 credits per image

### Character Consistency Best Practices

**Use 2–3 clear, well-lit reference shots:**
- Frontal view (primary identity anchor)
- 3/4-angle view (dimensional understanding)
- Side profile (silhouette + hair/ear/jawline)

**Outfit descriptions must be specific:**
- ~~"casual clothes"~~ → `fitted olive-green cotton t-shirt, dark indigo slim jeans, white leather sneakers with red accents`
- Include materials, colors, and distinctive details that the model can anchor to

**In I2V workflows — describe action, not appearance:**
The reference image already carries the character's visual identity. Re-describing their appearance creates conflict.

- **Wrong:** `@Image1 — A woman with curly brown hair and green eyes wearing a red jacket walks through the park.`
- **Right:** `@Image1 — She walks through the park, pausing to look up at the falling leaves. Camera: slow tracking alongside.`

**If features drift between shots:**
Use the character sheet image directly as @Image1 for tighter identity anchoring. A clean, well-lit character sheet outperforms multiple casual photos.

**Multi-character scenes:**
Reference each character separately with distinct @Image tags:

```
@Image1 as Character A (the detective). @Image2 as Character B (the witness).
Character A leans across the table, speaking firmly. Character B looks away, fidgeting.
Camera: slow push-in on Character B's face.
```

---

## Soul Cinema as the CS 3.0/3.5 Default Image Model

**Soul Cinema** is the default Cinematic model in the Cinema Studio 3.0 and 3.5 image-mode picker — the model that runs when you toggle Cinema Studio into image mode and do not change the model selection. It is shared across both Cinema Studio versions and is distinct from the older standalone "Soul Cinema Preview" model and from the separately-named Featured-list "Higgsfield Soul Cinema" (see `../higgsfield-cinema/higgsfield-cinema.md` § Image Mode for the disambiguation).

**It is a single-step generator.** Soul Cinema takes a scene idea
("Describe the scene you imagine") and renders it directly with a cinematic-
grade film aesthetic — one prompt → one batch of images, no compositing or
multi-pass flow required. The standalone Image-tab controls are: aspect ratio
(e.g. 16:9), resolution (e.g. 2k), the enhancer toggle (On/Off), batch size
(e.g. 1/4), an optional **Color Transfer** control (pull a reference image's
color/grade onto the generation), and an optional **+ Character** reference
(a Soul ID or character image). Cost is roughly 0.125 credits per single image
(~0.5 per 4-image batch). The Two-Tool Refinement Pipeline above is an
*optional* second pass through GPT Image 2 when a shot needs a specific edit —
not a requirement of Soul Cinema itself, which stands alone as a single-step
cinematic scene generator.

That price point is why the Seedance-4K film tutorial reaches for Soul Cinema
"always" for **location plates and characters built from scratch** — its
on-screen pricing showed 1 credit = 8 images, the cheapest sheet-making pass
on the platform [DEMO — pricing shown on-screen; verify against the current
UI before promising it]. Soul Cinema quality tops out at 2k, so sheets that
must be 4K finish in GPT Image 2 or Nano Banana Pro — the full ladder is in
`../../templates/ad-asset-prep.md` § Which model makes the sheet.

### Soul ID identity prompting in Soul Cinema

When a Soul ID is active and Soul Cinema is the selected image model, the same **Identity vs. Motion separation** rule documented above applies — but Soul Cinema's general-purpose cinematic weighting means the Identity Block does most of the work and the "Motion Block" is replaced by a **Scene/Style Block** (since image generation has no temporal dimension).

**Identity Block** — Soul ID reference + static descriptors only:
```
The Soul ID character — [face/body/wardrobe descriptors only, no camera or motion language].
```

**Scene/Style Block** — environment + lighting + style direction:
```
[Setting], [time of day], [lighting quality], [color palette].
Style: Cinematic, [grade], [aspect ratio].
```

Keep the two blocks textually separate in the prompt. Do not re-describe identity inside the Scene/Style block — Soul Cinema is sensitive to identity drift if face/wardrobe descriptors leak into environmental phrasing. For broader picker context (when to pick Soul Cinema vs Cinematic Characters vs Cinematic Locations vs Cinematic Cameras), see `../higgsfield-cinema/higgsfield-cinema.md` § Per-Cinematic-model selection guide.

### Studio Look vs. Cinematic Look — Soul Cinema as the Re-Pass

When a model returns a character that reads as **studio-feeling** — clean,
evenly lit, glossy, slightly plastic — the result is not a final. It's an
intermediate. The studio look is what the model defaults to when no atmosphere
or grade is doing work in the prompt; it's competently rendered but reads as
"AI-generated" rather than "filmed." (Distinct from **Cinema Studio**, the
product — here "studio" describes a visual quality of the output, not the
generation environment that produced it.) The fix is to treat the studio-feeling
output as a starting frame and re-pass it through Soul Cinema with explicit
cinematic direction — palette, grade, lens character, lighting language — until
the look lands.

These rules are adapted from the Mr. Core methodology.

**Diagnose the studio look.** Symptoms: skin reads as smooth/even rather than
specular; lighting feels evenly distributed (no key/fill ratio, no directional
shadow); palette is wide and accurate rather than graded; clothing fabric
reads as new and clean rather than worn or weighted; the frame as a whole
looks like a product photograph rather than a film still.

**The re-pass workflow.** Take the studio-feeling output and:

1. Use it as a reference upload into Soul Cinema (or use Edit Shot in Seedance
   if you want to preserve identity exactly and modify only the look).
2. Add an explicit grade direction — "Bleach Bypass," "Teal Orange Epic,"
   "Sodium Decay," "Bleached Warm" — pick from the Cinema Studio 3.5 Color
   Palette presets in `../higgsfield-cinema/higgsfield-cinema.md` § Style Settings, or
   describe one in Manual Style.
3. Add directional lighting language — single key source, side rim, contre-jour,
   silhouette — not "well-lit" or "evenly lit."
4. Add lens character — Vintage Haze, Warm Halation, Anamorphic — to break the
   default clinical sharpness.
5. Add a palette compression — "muted," "desaturated," "crushed blacks" — to
   pull the wide accurate palette into a graded one.

The studio look is a stop on the path, not the destination. Plan for the
re-pass as part of the workflow; don't treat the first generation as the
final.

> **Scope** (`../shared/house-rulings.md` P2-3). The re-pass adds exactly what
> § The Reference Plate switches off — grade, directional light, lens
> character — so its output is a **derived look frame**: a final still, or a
> start frame whose look *is* the shot. It is never the identity base and never
> a plate that downstream generations read as a reference. Run it on a copy;
> the base close-up does not take the pass (§ The Untouched Base).

---

## Related skills
- `higgsfield-prompt` — MCSLA formula, Identity vs. Motion separation rule
- `higgsfield-cinema` — Cinema Studio Reference Anchor, Soul Cast, @ Elements
- `higgsfield-moodboard` — Soul Hex color palette for character consistency
- `higgsfield-pipeline` — Multi-shot workflow with Soul ID
- `higgsfield-recall` — Pre-generation memory check for character drift history
- `templates/` — Templates 03, 04, 05, 06, 08, 09, 10 include Identity/Motion Block examples
